package Controller;

import View.HomeScreen;
import View.GameRulesScreen;

import javax.swing.*;

public class HomeScreenController {

    private HomeScreen view;

    public HomeScreenController(HomeScreen view) {
        this.view = view;

        this.view.getBtnStartNewGame().addActionListener(e -> openGameRules());
        this.view.getBtnViewHistory().addActionListener(e -> openHistory());
        this.view.getBtnViewQuestions().addActionListener(e -> openQuestions());
    }

    private void openGameRules() {
        GameRulesScreen rules = new GameRulesScreen(view);
        rules.setVisible(true);
        view.setVisible(false);
    }

    private void openHistory() {
       
    }

    private void openQuestions() {
       
    }
}
