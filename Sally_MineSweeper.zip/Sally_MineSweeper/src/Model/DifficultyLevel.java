package Model;

public enum DifficultyLevel {
    EASY,
    MEDIUM,
    HARD
}
