package View;

import Controller.HomeScreenController;
import javax.swing.SwingUtilities;

public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            HomeScreen home = new HomeScreen();     
            new HomeScreenController(home);        
        });
    }
}
