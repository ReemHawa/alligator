package View;

import javax.swing.*;
import java.awt.*;

public class HomeScreen extends JFrame {

    private JButton btnStartNewGame;
    private JButton btnViewHistory;
    private JButton btnViewQuestions;


    public HomeScreen() {

        setTitle("MineSweeper - Home");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        BackgroundPanel bg = new BackgroundPanel();      
        bg.setLayout(null);                              
        setContentPane(bg);

        setSize(800, 550);
        setLocationRelativeTo(null);

                JLabel title = new JLabel("Welcome To Minesweeper", SwingConstants.CENTER);
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Serif", Font.BOLD, 28));
        title.setBounds(200, 60, 400, 40);
        bg.add(title);

                JLabel sub = new JLabel("Start the game when you're ready :)", SwingConstants.CENTER);
        sub.setForeground(Color.WHITE);
        sub.setFont(new Font("Serif", Font.PLAIN, 16));
        sub.setBounds(230, 100, 340, 30);
        bg.add(sub);
        
        btnViewHistory = new JButton("View Games History");
        btnViewHistory.setBounds(270, 190, 260, 40);
        bg.add(btnViewHistory);
        btnViewQuestions = new JButton("View Question Management");
        btnViewQuestions.setBounds(270, 250, 260, 40);
        bg.add(btnViewQuestions);
        btnStartNewGame = new JButton("Start A New Game");
        btnStartNewGame.setBounds(270, 310, 260, 40);
        bg.add(btnStartNewGame);

        setVisible(true);
    }

    public JButton getBtnStartNewGame() {
        return btnStartNewGame;
    }

    public JButton getBtnViewHistory() {
        return btnViewHistory;
    }

    public JButton getBtnViewQuestions() {
        return btnViewQuestions;
    }

    private static class BackgroundPanel extends JPanel {

        private final Image backgroundImage;

        public BackgroundPanel() {
            ImageIcon icon = new ImageIcon(
                    HomeScreen.class.getResource("homeBackground.png"));
            backgroundImage = icon.getImage();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0,
                        getWidth(), getHeight(), this);
            }
        }
    }
}
