package controller;

import view.HistoryView;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class HistoryScreenController {

    // list of all past games (dummy data for now)
    private final List<GameHistoryEntry> historyEntries = new ArrayList<>();

    public HistoryScreenController() {
        // ===== example data (same fields as the table) =====
        historyEntries.add(new GameHistoryEntry(
                "2025-11-10", "daniel", "sara",
                "Easy", "won", "10:00 min", 200));

        historyEntries.add(new GameHistoryEntry(
                "2025-10-25", "adam", "maya",
                "Hard", "lost", "15:01 min", 100));

        historyEntries.add(new GameHistoryEntry(
                "2025-10-09", "liam", "emma",
                "Medium", "won", "5:35 min", 160));

        historyEntries.add(new GameHistoryEntry(
                "2025-09-27", "noah", "olivia",
                "Easy", "won", "20:01 min", 180));

        historyEntries.add(new GameHistoryEntry(
                "2025-09-12", "ethan", "sophia",
                "Hard", "won", "13:33 min", 224));
    }

    // return one game by index
    public GameHistoryEntry getEntry(int index) {
        if (index < 0 || index >= historyEntries.size()) {
            throw new IllegalArgumentException("Invalid history index");
        }
        return historyEntries.get(index);
    }

    public int getNumberOfEntries() {
        return historyEntries.size();
    }

    // SHOW THE WHOLE DATA 
    public void showHistoryCard() {
        new HistoryView(this);
    }

    // model for one game
    public static class GameHistoryEntry {
        private final String date;
        private final String playerA;
        private final String playerB;
        private final String level;
        private final String result;
        private final String duration;
        private final int score;

        public GameHistoryEntry(String date, String playerA, String playerB,
                                String level, String result,
                                String duration, int score) {
            this.date = date;
            this.playerA = playerA;
            this.playerB = playerB;
            this.level = level;
            this.result = result;
            this.duration = duration;
            this.score = score;
        }

        public String getDate()     { return date; }
        public String getPlayerA()  { return playerA; }
        public String getPlayerB()  { return playerB; }
        public String getLevel()    { return level; }
        public String getResult()   { return result; }
        public String getDuration() { return duration; }
        public int    getScore()    { return score; }
    }

    // small main to test – shows card for FIRST game
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            HistoryScreenController controller = new HistoryScreenController();
            controller.showHistoryCard();   
        });
    }
}
