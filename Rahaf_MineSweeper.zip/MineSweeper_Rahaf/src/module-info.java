/**
 * 
 */
/**
 * 
 */
module MineSweeper_Rahaf {
	requires java.desktop;
}